import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws FileNotFoundException {
        //Main Variables
        ArrayList<String> code = new ArrayList<>();
        boolean codeRunning = true;
        int currentLinePointer = 0;
        VariableStorage variableStorage = new VariableStorage();
        ConditionStorage conditionStorage = new ConditionStorage();
        int currentIndentation;

        //Opens file and adds all contents to a String Array
        File file = new File("C:\\Users\\Charl\\IdeaProjects\\BareBonesInterpreter2\\src\\input.txt");
        Scanner reader = new Scanner(file);
        while(reader.hasNextLine()){
            code.add(reader.nextLine());
        }
        System.out.println(code);

        //Runs Code
        while (codeRunning){
            // Formats current line into String ArrayList
            String currentLine = code.get(currentLinePointer);
            ArrayList<String> currentLineArray = formatCode(currentLine);
            currentIndentation = findCurrentIndentation(currentLineArray);


            // Instruction Syntax Validation
            Instruction instruction = new Instruction();
            if(instruction.findIfInstructionExists(currentLineArray.get(currentIndentation))){
                instruction = new Instruction(currentLineArray.get(currentIndentation));
            }
            else {codeRunning = false;}

            // Handles the variables
            if(currentLineArray.size() > 1 + currentIndentation){
                String variableName = currentLineArray.get(1 + currentIndentation);

                //If variable exists
                Data variable = variableStorage.findItemInStorage(variableName);
                if(variable != null && !Objects.equals(instruction.getCurrentInstruction(), "while")){
                    instruction.doFunctionOnData(variable);
                }
                else if(Objects.equals(instruction.getCurrentInstruction(), "while")){
                    Condition condition = new Condition(variable, currentLineArray.get(2 + currentIndentation), Integer.parseInt(currentLineArray.get(3 + currentIndentation)), currentLinePointer);
                    if(condition.checkCondition()){
                        conditionStorage.addToStorage(condition);
                        currentLinePointer++;
                        continue;
                    }
                }
                else{
                    variable = new Data(variableName);
                    instruction.doFunctionOnData(variable);
                    variableStorage.addToStorage(variable);
                }
            }
            else if(Objects.equals(instruction.getCurrentInstruction(), "end")){
                Condition condition = conditionStorage.getItemAtLocation(currentIndentation);
                if(condition != null){
                    if(condition.checkCondition()){
                        currentLinePointer = condition.getConditionLocation();
                    }
                    else{conditionStorage.removeFromStorage(condition,currentIndentation);}
                }
            }

            // Shows current variables
            System.out.println(showCurrentVariableStorage(variableStorage));

            // Pointer Validation
            if(currentLinePointer < code.size() - 1){
                currentLinePointer++;
            }
            else {codeRunning = false;}
        }
    }

    // Puts line of code into an ArrayList
    // Removes spaces and semicolons
    private static ArrayList<String> formatCode(String lineOfCode){
        ArrayList<String> output = new ArrayList<>();
        String[] formattedCode = new String[10];
        String[] codeNoSpaces = lineOfCode.split(" ");
        int pointer = 0;
        boolean semiColonFound = false;
        int indentationCounter = 0;
        // Removes spaces and semicolons
        for(int i = 0; i < codeNoSpaces.length; i++){
            if (codeNoSpaces[i].endsWith(";")){
                formattedCode[pointer] = codeNoSpaces[i];
                pointer++;
                semiColonFound = true;
            }
            else if(!Objects.equals(codeNoSpaces[i], "")){
                formattedCode[pointer] = codeNoSpaces[i];
                pointer++;
            }
            else if(Objects.equals(codeNoSpaces[i], "") && !semiColonFound){
                indentationCounter++;
                if(indentationCounter % 3 == 0){
                    formattedCode[pointer] = " ";
                    pointer++;
                }
            }
        }
        for(int i = 0; i < formattedCode.length; i++){
            if(!Objects.equals(formattedCode[i], null)){
                if(formattedCode[i].endsWith(";")){
                    output.add(formattedCode[i].split(";")[0]);
                }
                else{ output.add(formattedCode[i]); }
            }
        }
        return output;
    }

    private static int findCurrentIndentation(ArrayList<String> currentLineArray){
        int count = 0;
        for (int i = 0; i < currentLineArray.size(); i++){
            if(Objects.equals(currentLineArray.get(i), " ")){
                count++;
            }
        }
        return count;
    }

    private static String showCurrentVariableStorage(VariableStorage varStore){
        ArrayList<Data> temp = varStore.getVariables();
        StringBuilder output = new StringBuilder("Current Variable Storage: ");
        for(int i = 0; i < temp.size(); i++){
            Data d = temp.get(i);
            output.append(d.getVarName()).append(" = ").append(d.getVarValue()).append(", ");
        }
        return output.toString();
    }

}