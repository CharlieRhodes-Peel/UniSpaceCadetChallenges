import java.util.Objects;

public class Condition {
    private final Data variable;
    private final String operator;
    private final int integer;
    private int conditionLocation;

    public Condition(){
        variable = null;
        this.operator = null;
        this.integer = 0;
        this.conditionLocation = 0;
    };
    public Condition(Data data, String operator, int integer, int conditionLine){
        this.variable = data;
        this.operator = operator;
        this.integer = integer;
        this.conditionLocation = conditionLine;
    }
    //PRIVATE METHODS

    public boolean checkCondition(){
        if(Objects.equals(operator, "not")){
            return variable.getVarValue() != integer;
        }
        return false;
    }

    // GETS
    public Data getVariable(){return variable;}
    public int getConditionLocation(){return conditionLocation;}
    //SETS
    public void setConditionLocation(int i){conditionLocation = i;}
}
