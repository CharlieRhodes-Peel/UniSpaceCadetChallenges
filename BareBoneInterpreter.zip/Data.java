public class Data {
    //PROPERTIES
    private String varName;
    private int varValue;

    //CONSTRUCTOR
    public Data(){
        varName = "";
        varValue = 0;
    }
    public Data(String inputName){
        varName = inputName;
        varValue = 0;
    }
    public Data(String inputName, int inputValue){
        varValue = inputValue;
        varName = inputName;
    }

    //METHODS

    //GETS
    public int getVarValue(){return varValue;}
    public String getVarName(){return  varName;}

    //SETS
    public void setVarValue(int x){varValue = x; System.out.println(varName + " = " + varValue);}
    public void setVarName(String s) {varName = s;}
}
