import java.util.ArrayList;
import java.util.Objects;
public class Instruction {
    //PROPERTIES
    private final String[] instructions = {"clear", "incr", "decr", "while", "end"};
    private final String currentInstruction;

    //CONSTRUCTORS
    public Instruction(){
        currentInstruction = null;
    }
    public Instruction(String s){
        currentInstruction = s;
    }

    //PRIVATE METHODS
    private int Clear(){
        System.out.println("Clearing: ");
        return 0;
    }
    private int Increment(int x){
        System.out.println("Incrementing: " + x);
        return x + 1;
    }

    private int Decrement(int x){
        System.out.println("Decrementing:" + x);
        return x - 1;
    }

    // PUBLIC METHODS

    public boolean findIfInstructionExists(String instruction){
        for (int i = 0; i < instructions.length; i++){
            if(Objects.equals(instruction, instructions[i])){
                return true;
            }
        }
        return false;
    }

    public void doFunctionOnData(Data data){
        if(Objects.equals(currentInstruction, instructions[0])){ // Clear
            data.setVarValue(Clear());
        }
        else if(Objects.equals(currentInstruction, instructions[1])){ // incr
            data.setVarValue(Increment(data.getVarValue()));
        }
        else if(Objects.equals(currentInstruction, instructions[2])){ //decr
            data.setVarValue(Decrement(data.getVarValue()));
        }
    }
    // GETS
    public String getCurrentInstruction(){return currentInstruction;}
}
