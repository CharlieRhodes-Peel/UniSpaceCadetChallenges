import java.util.ArrayList;
import java.util.Objects;

public class VariableStorage {
    ArrayList<Data> variableNames = new ArrayList<>();

    //Methods
    public void addToStorage(Data variable){
        variableNames.add(variable);
        System.out.println("Added: " + variable.getVarName() + " to VariableStorage");
    }

    //CHECKS IF VARIABLE IS IN STORAGE VIA NAME
    //RETURNS NULL IF NOT FOUND
    public Data findItemInStorage(String nameOfVariable){
        for (int i = 0; i < variableNames.size(); i++){
            Data beingChecked = variableNames.get(i);
            if(Objects.equals(nameOfVariable, beingChecked.getVarName())){
                return beingChecked;
            }
        }
        return null;
    }
    // GETS
    public ArrayList<Data> getVariables(){return variableNames;}
}
