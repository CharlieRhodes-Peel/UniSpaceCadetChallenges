import java.util.ArrayList;
import java.util.Objects;

public class ConditionStorage {
    ArrayList<Condition> conditions = new ArrayList<>();

    //Methods
    public void addToStorage(Condition condition){
        System.out.println("Adding condition to storage");
        conditions.add(condition);
    }
    public void removeFromStorage(Condition condition, int indentation){
        System.out.println("Removing condition at line: " + condition.getConditionLocation() + 1);
        conditions.remove(indentation);
    }

    //CHECKS IF VARIABLE IS IN STORAGE VIA CONDITION LOCATION
    //RETURNS NULL IF NOT FOUND
    public Condition findItemInStorage(int conditionLine){
        for (int i = 0; i < conditions.size(); i++){
            Condition beingChecked = conditions.get(i);
            if(Objects.equals(conditionLine, beingChecked.getConditionLocation())){
                return beingChecked;
            }
        }
        return null;
    }

    public Condition getItemAtLocation(int indentation){ return conditions.get(indentation);}
}
